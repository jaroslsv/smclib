(C) Yaroslav Kovalev 2025

A library for simple Monte-Carlo simulations

Examples are found in the 'examples' folder